// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.test.hotelbooking;

/**
 * @see org.andromda.test.hotelbooking.Hotel
 */
public class HotelDaoImpl
    extends org.andromda.test.hotelbooking.HotelDaoBase
{
}