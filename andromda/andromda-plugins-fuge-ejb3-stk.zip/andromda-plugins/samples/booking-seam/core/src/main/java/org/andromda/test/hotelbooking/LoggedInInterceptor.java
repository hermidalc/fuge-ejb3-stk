// license-header java merge-point
package org.andromda.test.hotelbooking;

/**
 * Interceptor class LoggedInInterceptor
 */
public class LoggedInInterceptor 
{
    /**
     * Default interceptor execution method
     *
     * @param ctx the invocation context
     * @return 
     */
    @javax.interceptor.AroundInvoke
    public Object execute(javax.interceptor.InvocationContext ctx)
        throws Exception 
    {
        // Add implementation
        
        try
        {
            return ctx.proceed();
        }
        catch (Exception e)
        {
            throw e;
        }
    }
}
