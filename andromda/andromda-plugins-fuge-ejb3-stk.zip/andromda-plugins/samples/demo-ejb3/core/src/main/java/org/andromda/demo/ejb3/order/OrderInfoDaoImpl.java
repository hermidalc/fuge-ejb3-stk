// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.demo.ejb3.order;

/**
 * @see org.andromda.demo.ejb3.order.OrderInfo
 */
public class OrderInfoDaoImpl
    extends org.andromda.demo.ejb3.order.OrderInfoDaoBase
{
}