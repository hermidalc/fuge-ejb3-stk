// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.demo.ejb3.rental;

/**
 * @see org.andromda.demo.ejb3.rental.RentalCar
 */
public class RentalCarDaoImpl
    extends org.andromda.demo.ejb3.rental.RentalCarDaoBase
{
    /**
     * @see org.andromda.demo.ejb3.rental.RentalCarDao#allCarsAreRented()
     */
    protected boolean handleAllCarsAreRented()
    {
        // TODO implement public boolean handleAllCarsAreRented()
        return false;
    }

}