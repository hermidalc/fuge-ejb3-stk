// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.demo.ejb3.customer;

/**
 * @see org.andromda.demo.ejb3.customer.Contact
 */
public class ContactImpl
    extends org.andromda.demo.ejb3.customer.Contact
    implements java.io.Serializable
{

    /** 
     * The serial version UID of this class. Needed for serialization. 
     */
    private static final long serialVersionUID = 1240192948153809747L;
    
}