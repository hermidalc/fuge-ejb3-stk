// Name: TimecardDaoImpl.cs
// license-header cs merge-point
//
// This is only generated once! It will never be overwritten.
// You can (and have to!) safely modify it by hand.

using System;
using Northwind.TimeTracker.VO;

namespace Northwind.TimeTracker.Domain
{
    public class TimecardDaoImpl : TimecardDaoBase
    {
        public override TimecardVO ToTimecardVO(Timecard entity)
        {
            // Entity to VO conversion
            TimecardVO valueObject = new TimecardVO();

            valueObject.StartDate = entity.StartDate;
            valueObject.Comments = entity.Comments;
            valueObject.Id = entity.Id;

            return valueObject;
        }

        public override Timecard TimecardVOToEntity(TimecardVO timecardVO)
        {
            // VO to entity conversion
            Timecard entity = Timecard.Factory.newInstance();

            entity.StartDate = timecardVO.StartDate;
            entity.Comments = timecardVO.Comments;

            return entity;
        }
    }
}
