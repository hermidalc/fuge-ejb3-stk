package org.andromda.cartridges.seam.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.seam.metafacades.SeamActivityGraph.
 *
 * @see org.andromda.cartridges.seam.metafacades.SeamActivityGraph
 */
public class SeamActivityGraphLogicImpl
    extends SeamActivityGraphLogic
{

    public SeamActivityGraphLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}