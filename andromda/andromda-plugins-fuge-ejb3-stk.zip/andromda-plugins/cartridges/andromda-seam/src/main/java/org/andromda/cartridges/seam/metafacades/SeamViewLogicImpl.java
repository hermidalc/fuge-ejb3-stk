package org.andromda.cartridges.seam.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.seam.metafacades.SeamView.
 *
 * @see org.andromda.cartridges.seam.metafacades.SeamView
 */
public class SeamViewLogicImpl
    extends SeamViewLogic
{

    public SeamViewLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}