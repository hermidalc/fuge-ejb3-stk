package org.andromda.cartridges.seam.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.seam.metafacades.SeamUseCase.
 *
 * @see org.andromda.cartridges.seam.metafacades.SeamUseCase
 */
public class SeamUseCaseLogicImpl
    extends SeamUseCaseLogic
{

    public SeamUseCaseLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}