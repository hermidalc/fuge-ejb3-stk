package org.andromda.cartridges.seam.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.seam.metafacades.SeamFinalState.
 *
 * @see org.andromda.cartridges.seam.metafacades.SeamFinalState
 */
public class SeamFinalStateLogicImpl
    extends SeamFinalStateLogic
{

    public SeamFinalStateLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}