package org.andromda.cartridges.seam.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.seam.metafacades.SeamManageableEntityAssociationEnd.
 *
 * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAssociationEnd
 */
public class SeamManageableEntityAssociationEndLogicImpl
    extends SeamManageableEntityAssociationEndLogic
{

    public SeamManageableEntityAssociationEndLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAssociationEnd#getMessageKey()
     */
    protected java.lang.String handleGetMessageKey()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAssociationEnd#getMessageValue()
     */
    protected java.lang.String handleGetMessageValue()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAssociationEnd#isSafeNamePresent()
     */
    protected boolean handleIsSafeNamePresent()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAssociationEnd#getOnlineHelpKey()
     */
    protected java.lang.String handleGetOnlineHelpKey()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAssociationEnd#getOnlineHelpValue()
     */
    protected java.lang.String handleGetOnlineHelpValue()
    {
        // TODO: put your implementation here.
        return null;
    }

}