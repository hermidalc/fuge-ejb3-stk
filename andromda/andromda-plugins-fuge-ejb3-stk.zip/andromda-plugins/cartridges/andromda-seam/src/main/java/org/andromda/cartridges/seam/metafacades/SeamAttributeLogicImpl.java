package org.andromda.cartridges.seam.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.seam.metafacades.SeamAttribute.
 *
 * @see org.andromda.cartridges.seam.metafacades.SeamAttribute
 */
public class SeamAttributeLogicImpl
    extends SeamAttributeLogic
{

    public SeamAttributeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}