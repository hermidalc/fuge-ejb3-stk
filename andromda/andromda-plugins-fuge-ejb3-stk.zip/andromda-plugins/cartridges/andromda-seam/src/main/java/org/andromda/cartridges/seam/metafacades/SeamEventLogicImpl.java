package org.andromda.cartridges.seam.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.seam.metafacades.SeamEvent.
 *
 * @see org.andromda.cartridges.seam.metafacades.SeamEvent
 */
public class SeamEventLogicImpl
    extends SeamEventLogic
{

    public SeamEventLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}