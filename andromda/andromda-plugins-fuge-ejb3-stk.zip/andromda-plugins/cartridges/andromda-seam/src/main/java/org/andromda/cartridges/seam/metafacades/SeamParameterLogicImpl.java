package org.andromda.cartridges.seam.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.seam.metafacades.SeamParameter.
 *
 * @see org.andromda.cartridges.seam.metafacades.SeamParameter
 */
public class SeamParameterLogicImpl
    extends SeamParameterLogic
{

    public SeamParameterLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}