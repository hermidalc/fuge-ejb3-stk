package org.andromda.cartridges.seam.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.seam.metafacades.SeamManageableEntityAttribute.
 *
 * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAttribute
 */
public class SeamManageableEntityAttributeLogicImpl
    extends SeamManageableEntityAttributeLogic
{

    public SeamManageableEntityAttributeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAttribute#getMessageKey()
     */
    protected java.lang.String handleGetMessageKey()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAttribute#getMessageValue()
     */
    protected java.lang.String handleGetMessageValue()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAttribute#getDateFormat()
     */
    protected java.lang.String handleGetDateFormat()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAttribute#isNeedsFileUpload()
     */
    protected boolean handleIsNeedsFileUpload()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAttribute#isHidden()
     */
    protected boolean handleIsHidden()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAttribute#getWidgetType()
     */
    protected java.lang.String handleGetWidgetType()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAttribute#isStrictDateFormat()
     */
    protected boolean handleIsStrictDateFormat()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAttribute#getFieldRowCount()
     */
    protected java.lang.Integer handleGetFieldRowCount()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAttribute#getFieldColumnCount()
     */
    protected java.lang.Integer handleGetFieldColumnCount()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAttribute#isSafeNamePresent()
     */
    protected boolean handleIsSafeNamePresent()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAttribute#getOnlineHelpKey()
     */
    protected java.lang.String handleGetOnlineHelpKey()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntityAttribute#getOnlineHelpValue()
     */
    protected java.lang.String handleGetOnlineHelpValue()
    {
        // TODO: put your implementation here.
        return null;
    }

}