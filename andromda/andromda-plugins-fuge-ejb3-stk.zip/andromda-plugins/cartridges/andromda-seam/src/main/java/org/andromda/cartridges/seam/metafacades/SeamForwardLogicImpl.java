package org.andromda.cartridges.seam.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.seam.metafacades.SeamForward.
 *
 * @see org.andromda.cartridges.seam.metafacades.SeamForward
 */
public class SeamForwardLogicImpl
    extends SeamForwardLogic
{

    public SeamForwardLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}