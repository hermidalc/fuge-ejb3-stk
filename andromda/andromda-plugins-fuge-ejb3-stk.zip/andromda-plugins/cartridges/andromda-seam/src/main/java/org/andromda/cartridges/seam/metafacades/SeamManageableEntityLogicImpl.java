package org.andromda.cartridges.seam.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.seam.metafacades.SeamManageableEntity.
 *
 * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity
 */
public class SeamManageableEntityLogicImpl
    extends SeamManageableEntityLogic
{

    public SeamManageableEntityLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getPageName()
     */
    protected java.lang.String handleGetPageName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getPageFullPath()
     */
    protected java.lang.String handleGetPageFullPath()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getPageTitleKey()
     */
    protected java.lang.String handleGetPageTitleKey()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getPageTitleValue()
     */
    protected java.lang.String handleGetPageTitleValue()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getListName()
     */
    protected java.lang.String handleGetListName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getFormBeanType()
     */
    protected java.lang.String handleGetFormBeanType()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getFormBeanName()
     */
    protected java.lang.String handleGetFormBeanName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getExceptionKey()
     */
    protected java.lang.String handleGetExceptionKey()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getActionType()
     */
    protected java.lang.String handleGetActionType()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getActionFullPath()
     */
    protected java.lang.String handleGetActionFullPath()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getActionPath()
     */
    protected java.lang.String handleGetActionPath()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getActionClassName()
     */
    protected java.lang.String handleGetActionClassName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getExceptionPath()
     */
    protected java.lang.String handleGetExceptionPath()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#isPreload()
     */
    protected boolean handleIsPreload()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getFormBeanClassName()
     */
    protected java.lang.String handleGetFormBeanClassName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getFormBeanFullPath()
     */
    protected java.lang.String handleGetFormBeanFullPath()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getListGetterName()
     */
    protected java.lang.String handleGetListGetterName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getListSetterName()
     */
    protected java.lang.String handleGetListSetterName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getMessageKey()
     */
    protected java.lang.String handleGetMessageKey()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getMessageValue()
     */
    protected java.lang.String handleGetMessageValue()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getActionParameter()
     */
    protected java.lang.String handleGetActionParameter()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getOnlineHelpKey()
     */
    protected java.lang.String handleGetOnlineHelpKey()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getOnlineHelpValue()
     */
    protected java.lang.String handleGetOnlineHelpValue()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getOnlineHelpActionPath()
     */
    protected java.lang.String handleGetOnlineHelpActionPath()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getOnlineHelpPagePath()
     */
    protected java.lang.String handleGetOnlineHelpPagePath()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#isTableExportable()
     */
    protected boolean handleIsTableExportable()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getTableExportTypes()
     */
    protected java.lang.String handleGetTableExportTypes()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#getTableMaxRows()
     */
    protected int handleGetTableMaxRows()
    {
        // TODO: put your implementation here.
        return 0;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#isTableSortable()
     */
    protected boolean handleIsTableSortable()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.cartridges.seam.metafacades.SeamManageableEntity#isMultipartFormData()
     */
    protected boolean handleIsMultipartFormData()
    {
        // TODO: put your implementation here.
        return false;
    }

}