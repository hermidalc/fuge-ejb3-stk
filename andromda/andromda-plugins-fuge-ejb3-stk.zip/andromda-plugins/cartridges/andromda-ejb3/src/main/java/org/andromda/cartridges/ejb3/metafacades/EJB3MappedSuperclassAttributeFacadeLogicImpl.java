package org.andromda.cartridges.ejb3.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.ejb3.metafacades.EJB3MappedSuperclassAttributeFacade.
 *
 * @see org.andromda.cartridges.ejb3.metafacades.EJB3MappedSuperclassAttributeFacade
 */
public class EJB3MappedSuperclassAttributeFacadeLogicImpl
    extends EJB3MappedSuperclassAttributeFacadeLogic
{

    public EJB3MappedSuperclassAttributeFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}