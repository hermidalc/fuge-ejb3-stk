package org.andromda.cartridges.ejb3.metafacades;

/**
 * MetafacadeLogic implementation for org.andromda.cartridges.ejb3.metafacades.EJB3ManageableEntityAttributeFacade.
 *
 * @see org.andromda.cartridges.ejb3.metafacades.EJB3ManageableEntityAttributeFacade
 */
public class EJB3ManageableEntityAttributeFacadeLogicImpl
    extends EJB3ManageableEntityAttributeFacadeLogic
{
    public EJB3ManageableEntityAttributeFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}