package org.andromda.cartridges.ejb3.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.ejb3.metafacades.EJB3MappedSuperclassFacade.
 *
 * @see org.andromda.cartridges.ejb3.metafacades.EJB3MappedSuperclassFacade
 */
public class EJB3MappedSuperclassFacadeLogicImpl
    extends EJB3MappedSuperclassFacadeLogic
{
    public EJB3MappedSuperclassFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}