package org.andromda.cartridges.ejb3.metafacades;

/**
 * MetafacadeLogic implementation for org.andromda.cartridges.ejb3.metafacades.EJB3ManageableEntityAssociationEndFacade.
 *
 * @see org.andromda.cartridges.ejb3.metafacades.EJB3ManageableEntityAssociationEndFacade
 */
public class EJB3ManageableEntityAssociationEndFacadeLogicImpl
    extends EJB3ManageableEntityAssociationEndFacadeLogic
{
    public EJB3ManageableEntityAssociationEndFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}