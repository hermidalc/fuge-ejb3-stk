This is the AndroMDA .NET Application Generator Maven Plugin and is the first
of two pieces needed to generate .NET AndroMDA applications. Download and install
this plugin as well as the csharp project
(http://andromdaplugins.cvs.sourceforge.net/andromdaplugins/plugins/andromdapp/projects/csharp/maven2/)

To install, download the source code from here http://andromdaplugins.cvs.sourceforge.net/andromdaplugins/plugins/maven2/plugins/andromdanetapp/
and type 'mvn install' at the command line. Then do the same for the csharp project.