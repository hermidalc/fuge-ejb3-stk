using System;


namespace nUGSoft.BusinessEntities
{
    public class FooBar
    {
        private int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private bool? _testBool;

        public bool? TestBool
        {
            get { return _testBool; }
            set { _testBool = value; }
        }
        private byte? _testByte;

        public byte? TestByte
        {
            get { return _testByte; }
            set { _testByte = value; }
        }
        private char? _testChar;

        public char? TestChar
        {
            get { return _testChar; }
            set { _testChar = value; }
        }
        private DateTime? _testDateTime;

        public DateTime? TestDateTime
        {
            get { return _testDateTime; }
            set { _testDateTime = value; }
        }
        private decimal? _testDecimal;

        public decimal? TestDecimal
        {
            get { return _testDecimal; }
            set { _testDecimal = value; }
        }
        private double? _testDouble;

        public double? TestDouble
        {
            get { return _testDouble; }
            set { _testDouble = value; }
        }
        private Guid? _testGuid;

        public Guid? TestGuid
        {
            get { return _testGuid; }
            set { _testGuid = value; }
        }
        private Int16? _testInt16;

        public Int16? TestInt16
        {
            get { return _testInt16; }
            set { _testInt16 = value; }
        }
        private Int32? _testInt32;

        public Int32? TestInt32
        {
            get { return _testInt32; }
            set { _testInt32 = value; }
        }
        private Int64? _testInt64;

        public Int64? TestInt64
        {
            get { return _testInt64; }
            set { _testInt64 = value; }
        }
        private SByte? _testSByte;

        public SByte? TestSByte
        {
            get { return _testSByte; }
            set { _testSByte = value; }
        }
        private Single? _testSingle;

        public Single? TestSingle
        {
            get { return _testSingle; }
            set { _testSingle = value; }
        }        
    }
}
