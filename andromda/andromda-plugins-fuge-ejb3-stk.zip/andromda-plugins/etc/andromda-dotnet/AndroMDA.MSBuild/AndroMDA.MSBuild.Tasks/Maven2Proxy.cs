using System;
using System.Collections.Generic;
using System.Text;

namespace AndroMDA.MSBuild.Tasks
{
    class Maven2Proxy
    {
    }
}
