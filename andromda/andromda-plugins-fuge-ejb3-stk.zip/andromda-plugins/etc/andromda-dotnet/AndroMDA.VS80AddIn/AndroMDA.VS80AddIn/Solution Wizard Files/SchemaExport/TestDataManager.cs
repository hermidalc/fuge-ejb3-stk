//
// TestDataManager.cs
// 

#region Using Statements

using System;
using System.Configuration;
using NHibernate;
using AndroMDA.NHibernateSupport;

#endregion

namespace ${wizard.solution.name}.SchemaExport
{
	public class TestDataManager
	{
		public static void InsertTestData()
		{
            // Insert test data here
		}
	}
}
