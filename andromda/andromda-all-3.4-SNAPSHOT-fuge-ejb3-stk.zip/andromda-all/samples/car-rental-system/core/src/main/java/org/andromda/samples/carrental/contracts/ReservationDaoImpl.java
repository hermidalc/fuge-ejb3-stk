// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.samples.carrental.contracts;

/**
 * @see org.andromda.samples.carrental.contracts.Reservation
 */
public class ReservationDaoImpl
    extends org.andromda.samples.carrental.contracts.ReservationDaoBase
{
}