// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.samples.carrental.customers;

/**
 * @see org.andromda.samples.carrental.customers.CustomerService
 */
public class CustomerServiceImpl
    extends org.andromda.samples.carrental.customers.CustomerServiceBase
{

    /**
     * @see org.andromda.samples.carrental.customers.CustomerService#createCustomer(java.lang.String, java.lang.String, java.lang.String)
     */
    protected java.lang.String handleCreateCustomer(java.lang.String name, java.lang.String customerNo, java.lang.String password)
        throws java.lang.Exception
    {
        //@todo implement protected java.lang.String handleCreateCustomer(java.lang.String name, java.lang.String customerNo, java.lang.String password)
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.customers.CustomerService#addDriver(java.lang.String, org.andromda.samples.carrental.customers.DriverData)
     */
    protected java.lang.String handleAddDriver(java.lang.String customerId, org.andromda.samples.carrental.customers.DriverData driverData)
        throws java.lang.Exception
    {
        //@todo implement protected java.lang.String handleAddDriver(java.lang.String customerId, org.andromda.samples.carrental.customers.DriverData driverData)
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.customers.CustomerService#searchAllCustomers()
     */
    protected java.util.Collection handleSearchAllCustomers()
        throws java.lang.Exception
    {
        //@todo implement protected java.util.Collection handleSearchAllCustomers()
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.customers.CustomerService#authenticateAsCustomer(java.lang.String, java.lang.String)
     */
    protected java.lang.String handleAuthenticateAsCustomer(java.lang.String customerNo, java.lang.String password)
        throws java.lang.Exception
    {
        //@todo implement protected java.lang.String handleAuthenticateAsCustomer(java.lang.String customerNo, java.lang.String password)
        return null;
    }

}