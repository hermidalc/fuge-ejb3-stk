// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.samples.carrental.contracts;

/**
 * @see org.andromda.samples.carrental.contracts.Reservation
 */
public class ReservationImpl
    extends org.andromda.samples.carrental.contracts.Reservation
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 8662713071753922409L;

    /**
     * @see org.andromda.samples.carrental.contracts.Reservation#create(long, java.util.Date, java.lang.String)
     */
    public org.andromda.samples.carrental.contracts.Reservation create(long id, java.util.Date reservationDate, java.lang.String comfortClass)
    {
        //@todo implement public org.andromda.samples.carrental.contracts.Reservation create(long id, java.util.Date reservationDate, java.lang.String comfortClass)
        return null;
    }

}