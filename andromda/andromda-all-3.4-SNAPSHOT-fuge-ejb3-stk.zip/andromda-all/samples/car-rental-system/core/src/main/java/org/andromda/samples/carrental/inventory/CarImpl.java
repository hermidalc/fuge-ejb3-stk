// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.samples.carrental.inventory;

/**
 * @see org.andromda.samples.carrental.inventory.Car
 */
public class CarImpl
    extends org.andromda.samples.carrental.inventory.Car
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -2661310554395849743L;

    /**
     * @see org.andromda.samples.carrental.inventory.Car#create(java.lang.Long, java.lang.String, java.lang.String)
     */
    public org.andromda.samples.carrental.inventory.Car create(java.lang.Long id, java.lang.String registrationNumber, java.lang.String inventoryNumber)
    {
        //@todo implement public org.andromda.samples.carrental.inventory.Car create(java.lang.Long id, java.lang.String registrationNumber, java.lang.String inventoryNumber)
        return null;
    }

}