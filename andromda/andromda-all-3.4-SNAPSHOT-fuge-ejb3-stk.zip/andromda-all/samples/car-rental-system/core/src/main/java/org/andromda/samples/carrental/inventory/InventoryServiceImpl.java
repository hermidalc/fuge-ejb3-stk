// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.samples.carrental.inventory;

/**
 * @see org.andromda.samples.carrental.inventory.InventoryService
 */
public class InventoryServiceImpl
    extends org.andromda.samples.carrental.inventory.InventoryServiceBase
{

    /**
     * @see org.andromda.samples.carrental.inventory.InventoryService#createCarType(org.andromda.samples.carrental.inventory.CarTypeData)
     */
    protected java.lang.String handleCreateCarType(org.andromda.samples.carrental.inventory.CarTypeData typeData)
        throws java.lang.Exception
    {
        //@todo implement protected java.lang.String handleCreateCarType(org.andromda.samples.carrental.inventory.CarTypeData typeData)
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.inventory.InventoryService#createCar(org.andromda.samples.carrental.inventory.CarData, java.lang.String)
     */
    protected java.lang.String handleCreateCar(org.andromda.samples.carrental.inventory.CarData carData, java.lang.String carTypeId)
        throws java.lang.Exception
    {
        //@todo implement protected java.lang.String handleCreateCar(org.andromda.samples.carrental.inventory.CarData carData, java.lang.String carTypeId)
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.inventory.InventoryService#searchCarByComfortClass(java.lang.String)
     */
    protected java.util.Collection handleSearchCarByComfortClass(java.lang.String comfortClass)
        throws java.lang.Exception
    {
        //@todo implement protected java.util.Collection handleSearchCarByComfortClass(java.lang.String comfortClass)
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.inventory.InventoryService#searchAllCarTypes()
     */
    protected java.util.Collection handleSearchAllCarTypes()
        throws java.lang.Exception
    {
        //@todo implement protected java.util.Collection handleSearchAllCarTypes()
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.inventory.InventoryService#searchAllCars()
     */
    protected java.util.Collection handleSearchAllCars()
        throws java.lang.Exception
    {
        //@todo implement protected java.util.Collection handleSearchAllCars()
        return null;
    }

}