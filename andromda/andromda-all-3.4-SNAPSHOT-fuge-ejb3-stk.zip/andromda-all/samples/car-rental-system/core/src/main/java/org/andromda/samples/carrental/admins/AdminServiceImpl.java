// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.samples.carrental.admins;

/**
 * @see org.andromda.samples.carrental.admins.AdminService
 */
public class AdminServiceImpl
    extends org.andromda.samples.carrental.admins.AdminServiceBase
{

    /**
     * @see org.andromda.samples.carrental.admins.AdminService#authenticateAsAdministrator(java.lang.String, java.lang.String, java.lang.String)
     */
    protected java.lang.String handleAuthenticateAsAdministrator(java.lang.String name, java.lang.String accountNo, java.lang.String password)
        throws java.lang.Exception
    {
        //@todo implement protected java.lang.String handleAuthenticateAsAdministrator(java.lang.String name, java.lang.String accountNo, java.lang.String password)
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.admins.AdminService#createAdministrator(java.lang.String, java.lang.String, java.lang.String)
     */
    protected java.lang.String handleCreateAdministrator(java.lang.String name, java.lang.String accountNo, java.lang.String password)
        throws java.lang.Exception
    {
        //@todo implement protected java.lang.String handleCreateAdministrator(java.lang.String name, java.lang.String accountNo, java.lang.String password)
        return null;
    }

}