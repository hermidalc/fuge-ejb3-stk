// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.samples.carrental.contracts;

/**
 * @see org.andromda.samples.carrental.contracts.ContractService
 */
public class ContractServiceImpl
    extends org.andromda.samples.carrental.contracts.ContractServiceBase
{

    /**
     * @see org.andromda.samples.carrental.contracts.ContractService#searchForReservationsOfCustomer(java.lang.String)
     */
    protected java.util.Collection handleSearchForReservationsOfCustomer(java.lang.String customerId)
        throws java.lang.Exception
    {
        //@todo implement protected java.util.Collection handleSearchForReservationsOfCustomer(java.lang.String customerId)
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.contracts.ContractService#reserve(java.lang.String, java.lang.String, java.util.Date)
     */
    protected void handleReserve(java.lang.String customerId, java.lang.String comfortClass, java.util.Date reservationDate)
        throws java.lang.Exception
    {
        //@todo implement protected void handleReserve(java.lang.String customerId, java.lang.String comfortClass, java.util.Date reservationDate)
        throw new java.lang.UnsupportedOperationException("org.andromda.samples.carrental.contracts.ContractService.handleReserve(java.lang.String customerId, java.lang.String comfortClass, java.util.Date reservationDate) Not implemented!");
    }

    /**
     * @see org.andromda.samples.carrental.contracts.ContractService#handOutReservation(java.lang.String)
     */
    protected java.lang.String handleHandOutReservation(java.lang.String idReservation)
        throws java.lang.Exception
    {
        //@todo implement protected java.lang.String handleHandOutReservation(java.lang.String idReservation)
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.contracts.ContractService#returnCar(java.lang.String)
     */
    protected java.lang.String handleReturnCar(java.lang.String idContract)
        throws java.lang.Exception
    {
        //@todo implement protected java.lang.String handleReturnCar(java.lang.String idContract)
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.contracts.ContractService#searchForContractsOfCustomer(java.lang.String)
     */
    protected java.util.Collection handleSearchForContractsOfCustomer(java.lang.String idCustomer)
        throws java.lang.Exception
    {
        //@todo implement protected java.util.Collection handleSearchForContractsOfCustomer(java.lang.String idCustomer)
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.contracts.ContractService#registerAccident(java.lang.String)
     */
    protected java.lang.String handleRegisterAccident(java.lang.String idContract)
        throws java.lang.Exception
    {
        //@todo implement protected java.lang.String handleRegisterAccident(java.lang.String idContract)
        return null;
    }

}