// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.samples.carrental.admins;

import java.util.Collection;

/**
 * @see org.andromda.samples.carrental.admins.Administrator
 */
public class AdministratorImpl
    extends org.andromda.samples.carrental.admins.Administrator
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 2896231750025115135L;

    /**
     * @see org.andromda.samples.carrental.admins.Administrator#create(long, java.lang.String, java.lang.String, java.lang.String)
     */
    public org.andromda.samples.carrental.admins.Administrator create(long id, java.lang.String name, java.lang.String accountNo, java.lang.String password)
        throws org.andromda.samples.carrental.admins.AdminException
    {
        //@todo implement public org.andromda.samples.carrental.admins.Administrator create(long id, java.lang.String name, java.lang.String accountNo, java.lang.String password)
        return null;
    }

    public Collection findByAccountNo(String accountNo) throws org.andromda.samples.carrental.admins.AdminException
    {
        return null;
    }

    public Collection findAll() throws org.andromda.samples.carrental.admins.AdminException
    {
        return null;
    }
}